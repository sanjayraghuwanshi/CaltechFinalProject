package com.simplilearn.example.CaltechDevOps;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CaltechDevOpsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CaltechDevOpsApplication.class, args);
	}

}
