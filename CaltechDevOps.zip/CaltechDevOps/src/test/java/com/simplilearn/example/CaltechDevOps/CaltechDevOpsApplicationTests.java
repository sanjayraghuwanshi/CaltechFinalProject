package com.simplilearn.example.CaltechDevOps;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CaltechDevOpsApplicationTests {

	@Test
	void contextLoads() {
	}

}
